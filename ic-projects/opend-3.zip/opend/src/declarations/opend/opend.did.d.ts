import type { Principal } from '@dfinity/principal';
export interface _SERVICE {
  'mint' : (arg_0: Array<number>, arg_1: string) => Promise<Principal>,
}
